import { verifyToken } from '../utils/auth'

router.post('/:lang', verifyToken, addBlogPost) // blog.ts
router.post('/', verifyToken, addEvent) // events.ts
