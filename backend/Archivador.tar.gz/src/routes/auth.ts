import express, { Request, Response } from 'express'
import { generateToken } from '../utils/auth'
import dotenv from 'dotenv'

dotenv.config()

const router = express.Router()

router.post('/login', (req: Request, res: Response) => {
  const { email, password } = req.body

  const adminEmail = process.env.ADMIN_EMAIL
  const adminPassword = process.env.ADMIN_PASSWORD

  if (email === adminEmail && password === adminPassword) {
    const token = generateToken({ email })
    return res.status(200).json({ token })
  }

  return res.status(401).json({ error: "Credenciales inválidas" })
})

export default router
