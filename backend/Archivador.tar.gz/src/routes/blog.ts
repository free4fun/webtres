import express from 'express'
import { addBlogPost } from '../controllers/blogController'
import { verifyToken } from '../utils/auth'

const router = express.Router()
router.post('/:lang', verifyToken, addBlogPost)
export default router
