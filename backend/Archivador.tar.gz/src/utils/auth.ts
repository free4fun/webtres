import jwt from 'jsonwebtoken'
import { Request, Response, NextFunction } from 'express'

const secret = process.env.JWT_SECRET || "fallbacksecret"

export const generateToken = (payload: object): string =>
  jwt.sign(payload, secret, { expiresIn: "2h" })

export const verifyToken = (req: Request, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.split(" ")[1]
  if (!token) return res.status(401).json({ error: "Access denied. No token provided." })

  try {
    const decoded = jwt.verify(token, secret)
    ;(req as any).user = decoded
    next()
  } catch (err) {
    res.status(403).json({ error: "Invalid or expired token" })
  }
}
