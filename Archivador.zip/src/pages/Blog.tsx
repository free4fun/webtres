import { useEffect, useRef, useState } from "react"
import { useTranslation } from "react-i18next"
import { getPostsByLang } from "@/data/blog/getPostsByLang"
import { PostCard } from "@/components/PostCard"

const POSTS_PER_ROW = 3
const VISIBLE_ROWS = 2
const POSTS_PER_VIEW = POSTS_PER_ROW * VISIBLE_ROWS

const Blog = () => {
  const { t, i18n } = useTranslation()
  const allPosts = getPostsByLang(i18n.language).sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  )
  const total = allPosts.length

  const [startIndex, setStartIndex] = useState(0)
  const [loading, setLoading] = useState(false)
  const loaderRef = useRef<HTMLDivElement | null>(null)

  const getVisiblePosts = () => {
    let result: typeof allPosts = []
    for (let i = 0; i < POSTS_PER_VIEW; i++) {
      result.push(allPosts[(startIndex + i) % total])
    }
    return result
  }

  const visiblePosts = getVisiblePosts()

  useEffect(() => {
    if (!loaderRef.current) return

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0]
        if (entry.isIntersecting && !loading) {
          setLoading(true)
          setTimeout(() => {
            setStartIndex((prev) => (prev + POSTS_PER_ROW) % total)
            setLoading(false)
          }, 800)
        }
      },
      { threshold: 1 }
    )

    const el = loaderRef.current
    if (el) observer.observe(el)

    return () => {
      if (el) observer.unobserve(el)
    }
  }, [loading, total])

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-5xl mx-auto space-y-10">
        <h1 className="text-3xl font-bold tracking-tight">{t("blog.title")}</h1>

        {/* Grid fijo de 6 posts */}
        <div className="grid gap-6 md:grid-cols-3">
          {visiblePosts.map((post) => (
            <PostCard key={post.slug + startIndex} {...post} />
          ))}
        </div>

        {/* Loader trigger */}
        <div ref={loaderRef} className="h-10" />

        {/* Texto animado */}
        {loading && (
          <p className="text-center text-sm text-muted-foreground animate-pulse pt-4">
            {t("blog.loading")}
          </p>
        )}
      </div>
    </div>
  )
}

export default Blog
