const posts = () => {
  return ([
    {
      id: 1,
      title: "blog.1.title",
      summary: "blog.1.summary",
      date: "blog.1.date",
    },
    {
      id: 2,
      title: "blog.2.title",
      summary: "blog.2.summary",
      date: "blog.2.date",
    },
    {
      id: 3,
      title: "blog.3.title",
      summary: "blog.3.summary",
      date: "blog.3.date",
    },
  ])
}
export default posts;